SITE MARIAGE - CORALIE & VINCENT

Fichier principal :
- index.html

Pour GitHub Pages :
1. Créer un repository GitHub.
2. Ajouter uniquement index.html à la racine du repository.
3. Aller dans Settings > Pages.
4. Source : Deploy from a branch.
5. Branch : main / root.
6. Attendre quelques minutes.
7. Le site sera disponible via le lien GitHub Pages.

Important :
- Ne pas renommer index.html.
- Le RSVP est déjà connecté au Google Apps Script / Google Sheet.
